'use strict';

require('dotenv').config();

const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');

const { db } = require('./db');
const mail = require('./mail');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
const IS_PROD = process.env.NODE_ENV === 'production';
const SHOW_CODES = process.env.SHOW_CODES === 'true'; // dev only: returns OTP in the response
const OPENING_BALANCE_P = Math.round(Number(process.env.OPENING_BALANCE || 10000) * 100);
const DEFAULT_PIN = '00000';

app.set('trust proxy', 1);
app.use(express.json({ limit: '32kb' }));
app.use(cookieParser());

/* ---------------------------------------------------------------- helpers */

const PROVIDERS = {
  '0001119': { name: 'Razorpay', blurb: 'Cards, UPI and netbanking settlements' },
  '0091023': { name: 'Stripe', blurb: 'International card settlements' },
  '0099123': { name: 'PayU', blurb: 'Domestic collections and payouts' }
};

const OPERATORS = ['Airtel', 'Jio', 'Vi', 'BSNL'];
const GIFT_DISCOUNT = 0.08; // 8% off face value
const GIFT_FACES = [500, 1000, 2000, 5000];

const paise = (rupees) => Math.round(Number(rupees) * 100);
const inr = (p) =>
  '₹' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const pointsFor = (amountP) => Math.max(1, Math.floor((amountP / 100) * 0.05));

const reference = () =>
  'LSP' + Date.now().toString(36).toUpperCase() + crypto.randomBytes(2).toString('hex').toUpperCase();

const normEmail = (e) => String(e || '').trim().toLowerCase();
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const handleFor = (email) => email.split('@')[0].replace(/[^a-z0-9._-]/gi, '').slice(0, 24) || 'user';

function hash(value) {
  const salt = crypto.randomBytes(16).toString('hex');
  const digest = crypto.scryptSync(String(value), salt, 32).toString('hex');
  return { digest, salt };
}
function verifyHash(value, digest, salt) {
  const candidate = crypto.scryptSync(String(value), salt, 32);
  const known = Buffer.from(digest, 'hex');
  return known.length === candidate.length && crypto.timingSafeEqual(known, candidate);
}

function fail(res, status, message) {
  return res.status(status).json({ error: message });
}

/* ------------------------------------------------------------------- OTPs */

const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_COOLDOWN_MS = 45 * 1000;

const insertOtp = db.prepare(
  `INSERT INTO otps (email, purpose, code_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)`
);
const latestOtp = db.prepare(
  `SELECT * FROM otps WHERE email = ? AND purpose = ? ORDER BY id DESC LIMIT 1`
);

async function issueCode(email, purpose, sender) {
  const recent = latestOtp.get(email, purpose);
  if (recent && Date.now() - recent.created_at < OTP_COOLDOWN_MS && !recent.consumed) {
    const wait = Math.ceil((OTP_COOLDOWN_MS - (Date.now() - recent.created_at)) / 1000);
    return { ok: false, status: 429, message: `Wait ${wait}s before asking for another code.` };
  }

  const code = String(crypto.randomInt(100000, 1000000));
  const { digest, salt } = hash(code);
  insertOtp.run(email, purpose, `${salt}:${digest}`, Date.now() + OTP_TTL_MS, Date.now());

  const result = await sender(email, code);
  return { ok: true, delivered: result.delivered, reason: result.reason, code };
}

function consumeCode(email, purpose, code) {
  const row = latestOtp.get(email, purpose);
  if (!row) return { ok: false, message: 'Ask for a code first.' };
  if (row.consumed) return { ok: false, message: 'That code was already used. Ask for a new one.' };
  if (Date.now() > row.expires_at) return { ok: false, message: 'That code expired. Ask for a new one.' };
  if (row.attempts >= 5) return { ok: false, message: 'Too many wrong tries. Ask for a new code.' };

  const [salt, digest] = row.code_hash.split(':');
  if (!verifyHash(String(code).trim(), digest, salt)) {
    db.prepare('UPDATE otps SET attempts = attempts + 1 WHERE id = ?').run(row.id);
    return { ok: false, message: `Wrong code. ${4 - row.attempts} tries left.` };
  }
  db.prepare('UPDATE otps SET consumed = 1 WHERE id = ?').run(row.id);
  return { ok: true };
}

/* --------------------------------------------------------------- accounts */

const findUserByEmail = db.prepare('SELECT * FROM users WHERE email = ?');
const findUserById = db.prepare('SELECT * FROM users WHERE id = ?');

const createUser = db.transaction((email) => {
  const { digest, salt } = hash(DEFAULT_PIN);
  const info = db
    .prepare('INSERT INTO users (email, handle, pin_hash, pin_salt, balance_p) VALUES (?, ?, ?, ?, ?)')
    .run(email, handleFor(email), digest, salt, OPENING_BALANCE_P);

  if (OPENING_BALANCE_P > 0) {
    db.prepare(
      `INSERT INTO transactions (user_id, kind, direction, amount_p, points, title, detail, reference)
       VALUES (?, 'receive', 'credit', ?, 0, 'Welcome credit', 'Opening balance for your new wallet', ?)`
    ).run(info.lastInsertRowid, OPENING_BALANCE_P, reference());
  }
  return findUserById.get(info.lastInsertRowid);
});

function publicUser(u) {
  return {
    email: u.email,
    handle: u.handle,
    balance: u.balance_p / 100,
    balanceLabel: inr(u.balance_p),
    points: u.points,
    pinIsDefault: verifyHash(DEFAULT_PIN, u.pin_hash, u.pin_salt)
  };
}

function setSession(res, user) {
  const token = jwt.sign({ uid: user.id }, JWT_SECRET, { expiresIn: '30d' });
  res.cookie('lsp_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: IS_PROD,
    maxAge: 30 * 24 * 60 * 60 * 1000
  });
}

function auth(req, res, next) {
  const token = req.cookies?.lsp_session;
  if (!token) return fail(res, 401, 'Sign in to continue.');
  try {
    const { uid } = jwt.verify(token, JWT_SECRET);
    const user = findUserById.get(uid);
    if (!user) return fail(res, 401, 'Sign in to continue.');
    req.user = user;
    next();
  } catch {
    return fail(res, 401, 'Your session expired. Sign in again.');
  }
}

/* ------------------------------------------------------------------- PINs */

const pinLocks = new Map(); // userId -> { misses, until }

function checkPin(user, pin) {
  const lock = pinLocks.get(user.id);
  if (lock?.until && Date.now() < lock.until) {
    const mins = Math.ceil((lock.until - Date.now()) / 60000);
    return { ok: false, message: `PIN locked for ${mins} more minute(s).` };
  }
  if (!/^\d{5}$/.test(String(pin || ''))) return { ok: false, message: 'Enter your 5-digit PIN.' };

  if (!verifyHash(String(pin), user.pin_hash, user.pin_salt)) {
    const misses = (lock?.misses || 0) + 1;
    if (misses >= 5) {
      pinLocks.set(user.id, { misses: 0, until: Date.now() + 15 * 60 * 1000 });
      return { ok: false, message: 'Wrong PIN 5 times. Payments locked for 15 minutes.' };
    }
    pinLocks.set(user.id, { misses, until: 0 });
    return { ok: false, message: `Wrong PIN. ${5 - misses} tries left.` };
  }
  pinLocks.delete(user.id);
  return { ok: true };
}

/* --------------------------------------------------------------- payments */

const addTx = db.prepare(
  `INSERT INTO transactions (user_id, kind, direction, amount_p, points, title, detail, reference)
   VALUES (@user_id, @kind, @direction, @amount_p, @points, @title, @detail, @reference)`
);

/**
 * Debits the payer, credits points, and optionally credits a payee.
 * Runs as one SQLite transaction so a balance can never go negative halfway.
 */
const settle = db.transaction((payer, { amountP, kind, title, detail, payee, payeeTitle }) => {
  const fresh = findUserById.get(payer.id);
  if (fresh.balance_p < amountP) throw new Error('INSUFFICIENT');

  const earned = pointsFor(amountP);
  const ref = reference();

  db.prepare('UPDATE users SET balance_p = balance_p - ?, points = points + ? WHERE id = ?').run(
    amountP,
    earned,
    payer.id
  );
  addTx.run({
    user_id: payer.id,
    kind,
    direction: 'debit',
    amount_p: amountP,
    points: earned,
    title,
    detail: detail || null,
    reference: ref
  });

  if (payee) {
    db.prepare('UPDATE users SET balance_p = balance_p + ? WHERE id = ?').run(amountP, payee.id);
    addTx.run({
      user_id: payee.id,
      kind: 'receive',
      direction: 'credit',
      amount_p: amountP,
      points: 0,
      title: payeeTitle || `Received from ${payer.handle}`,
      detail: detail || null,
      reference: ref
    });
  }

  return { reference: ref, points: earned, balance_p: findUserById.get(payer.id).balance_p };
});

function amountCheck(raw, { min = 1, max = 200000 } = {}) {
  const rupees = Number(raw);
  if (!Number.isFinite(rupees) || rupees <= 0) return { ok: false, message: 'Enter an amount.' };
  if (rupees < min) return { ok: false, message: `Minimum is ${inr(paise(min))}.` };
  if (rupees > max) return { ok: false, message: `Maximum per payment is ${inr(paise(max))}.` };
  const p = paise(rupees);
  if (p !== Math.round(p)) return { ok: false, message: 'Use at most two decimal places.' };
  return { ok: true, amountP: p };
}

async function runPayment(req, res, { amountP, kind, title, detail, payee, payeeTitle, receiptTitle }) {
  const pinResult = checkPin(req.user, req.body.pin);
  if (!pinResult.ok) return fail(res, 403, pinResult.message);

  let out;
  try {
    out = settle(req.user, { amountP, kind, title, detail, payee, payeeTitle });
  } catch (err) {
    if (err.message === 'INSUFFICIENT') return fail(res, 400, 'Not enough balance for this payment.');
    throw err;
  }

  mail
    .sendReceipt(req.user.email, {
      title: receiptTitle || title,
      amountLabel: inr(amountP),
      reference: out.reference,
      detail,
      balanceLabel: inr(out.balance_p),
      points: out.points
    })
    .catch((e) => console.error('[mail] receipt failed:', e.message));

  return res.json({
    ok: true,
    reference: out.reference,
    amountLabel: inr(amountP),
    points: out.points,
    title,
    detail,
    user: publicUser(findUserById.get(req.user.id))
  });
}

/* ------------------------------------------------------------ rate limits */

const codeLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const payLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

/* ------------------------------------------------------------------ auth  */

app.post('/api/auth/request-code', codeLimiter, async (req, res) => {
  const email = normEmail(req.body.email);
  if (!validEmail(email)) return fail(res, 400, 'Enter a valid email address.');

  const out = await issueCode(email, 'login', mail.sendLoginCode);
  if (!out.ok) return fail(res, out.status, out.message);

  const existing = !!findUserByEmail.get(email);
  res.json({
    ok: true,
    email,
    existing,
    delivered: out.delivered,
    note: out.delivered ? null : `Email not sent: ${out.reason}. Check the server logs.`,
    devCode: SHOW_CODES ? out.code : undefined
  });
});

app.post('/api/auth/verify', codeLimiter, (req, res) => {
  const email = normEmail(req.body.email);
  if (!validEmail(email)) return fail(res, 400, 'Enter a valid email address.');

  const check = consumeCode(email, 'login', req.body.code);
  if (!check.ok) return fail(res, 400, check.message);

  const user = findUserByEmail.get(email) || createUser(email);
  setSession(res, user);
  res.json({ ok: true, user: publicUser(user) });
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('lsp_session');
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

/* ------------------------------------------------------------- 2. the PIN */

app.post('/api/pin/request-code', auth, codeLimiter, async (req, res) => {
  const out = await issueCode(req.user.email, 'pin_change', mail.sendPinChangeCode);
  if (!out.ok) return fail(res, out.status, out.message);
  res.json({
    ok: true,
    delivered: out.delivered,
    note: out.delivered ? null : `Email not sent: ${out.reason}. Check the server logs.`,
    devCode: SHOW_CODES ? out.code : undefined
  });
});

app.post('/api/pin/change', auth, (req, res) => {
  const newPin = String(req.body.newPin || '');
  if (!/^\d{5}$/.test(newPin)) return fail(res, 400, 'Your PIN must be exactly 5 digits.');
  if (/^(\d)\1{4}$/.test(newPin) && newPin !== DEFAULT_PIN)
    return fail(res, 400, 'Pick a PIN that is not the same digit five times.');

  const check = consumeCode(req.user.email, 'pin_change', req.body.code);
  if (!check.ok) return fail(res, 400, check.message);

  const { digest, salt } = hash(newPin);
  db.prepare('UPDATE users SET pin_hash = ?, pin_salt = ? WHERE id = ?').run(digest, salt, req.user.id);
  pinLocks.delete(req.user.id);
  res.json({ ok: true, user: publicUser(findUserById.get(req.user.id)) });
});

/* ------------------------------------------------------ 1. pay a provider */

app.get('/api/providers', auth, (req, res) => {
  res.json({
    providers: Object.entries(PROVIDERS).map(([code, p]) => ({ code, ...p }))
  });
});

app.post('/api/pay/provider', auth, payLimiter, async (req, res) => {
  const code = String(req.body.code || '').trim();
  const provider = PROVIDERS[code];
  if (!provider) return fail(res, 400, 'No provider matches that code.');

  const amt = amountCheck(req.body.amount);
  if (!amt.ok) return fail(res, 400, amt.message);

  return runPayment(req, res, {
    amountP: amt.amountP,
    kind: 'provider',
    title: `${provider.name} settlement`,
    detail: `Provider code ${code}${req.body.note ? ' · ' + String(req.body.note).slice(0, 80) : ''}`
  });
});

/* ------------------------------------------------------- pay another user */

app.get('/api/directory', auth, (req, res) => {
  const q = `%${String(req.query.q || '').trim().toLowerCase()}%`;
  const rows = db
    .prepare('SELECT email, handle FROM users WHERE id != ? AND (email LIKE ? OR handle LIKE ?) LIMIT 8')
    .all(req.user.id, q, q);
  res.json({ people: rows });
});

app.post('/api/pay/user', auth, payLimiter, async (req, res) => {
  const to = normEmail(req.body.to);
  if (!validEmail(to)) return fail(res, 400, 'Enter the receiver\u2019s email address.');
  if (to === req.user.email) return fail(res, 400, 'You cannot pay yourself.');

  const payee = findUserByEmail.get(to);
  if (!payee) return fail(res, 404, 'Nobody uses LSP-Pay with that email yet.');

  const amt = amountCheck(req.body.amount);
  if (!amt.ok) return fail(res, 400, amt.message);

  const note = String(req.body.note || '').slice(0, 80);
  return runPayment(req, res, {
    amountP: amt.amountP,
    kind: 'send',
    title: `Paid ${payee.handle}`,
    detail: note || null,
    payee,
    payeeTitle: `Received from ${req.user.handle}`,
    receiptTitle: `${payee.handle} (${payee.email})`
  });
});

/* -------------------------------------------------- 3. mobile recharge */

app.post('/api/recharge/mobile', auth, payLimiter, async (req, res) => {
  const phone = String(req.body.phone || '').replace(/\D/g, '');
  if (!/^[6-9]\d{9}$/.test(phone)) return fail(res, 400, 'Enter a 10-digit Indian mobile number.');

  const operator = OPERATORS.includes(req.body.operator) ? req.body.operator : 'Airtel';
  const amt = amountCheck(req.body.amount, { min: 10, max: 5000 });
  if (!amt.ok) return fail(res, 400, amt.message);

  return runPayment(req, res, {
    amountP: amt.amountP,
    kind: 'mobile',
    title: `${operator} recharge`,
    detail: `${phone.slice(0, 5)} ${phone.slice(5)}`
  });
});

/* -------------------------------------------------- 4. FASTag recharge */

app.post('/api/recharge/fastag', auth, payLimiter, async (req, res) => {
  const tag = String(req.body.tagId || '').replace(/\s/g, '').toUpperCase();
  if (!/^[A-Z0-9]{8,20}$/.test(tag)) return fail(res, 400, 'Enter a FASTag number of 8 to 20 characters.');

  const vehicle = String(req.body.vehicle || '').toUpperCase().replace(/\s/g, '').slice(0, 12);
  const amt = amountCheck(req.body.amount, { min: 100, max: 20000 });
  if (!amt.ok) return fail(res, 400, amt.message);

  return runPayment(req, res, {
    amountP: amt.amountP,
    kind: 'fastag',
    title: 'FASTag top-up',
    detail: `Tag ${tag}${vehicle ? ' · ' + vehicle : ''}`
  });
});

/* ------------------------------------------------------- 5. gift cards */

app.get('/api/giftcards', auth, (req, res) => {
  const mine = db
    .prepare(
      `SELECT code, face_p, paid_p, recipient, created_at, redeemed_at
       FROM gift_cards WHERE buyer_id = ? ORDER BY id DESC LIMIT 20`
    )
    .all(req.user.id);

  res.json({
    discount: GIFT_DISCOUNT,
    faces: GIFT_FACES.map((face) => ({
      face,
      faceLabel: inr(paise(face)),
      price: Math.round(face * (1 - GIFT_DISCOUNT)),
      priceLabel: inr(Math.round(paise(face) * (1 - GIFT_DISCOUNT))),
      saveLabel: inr(paise(face) - Math.round(paise(face) * (1 - GIFT_DISCOUNT)))
    })),
    cards: mine.map((c) => ({
      code: c.code,
      faceLabel: inr(c.face_p),
      paidLabel: inr(c.paid_p),
      recipient: c.recipient,
      createdAt: c.created_at,
      redeemed: !!c.redeemed_at
    }))
  });
});

app.post('/api/giftcards/buy', auth, payLimiter, async (req, res) => {
  const face = Number(req.body.face);
  if (!GIFT_FACES.includes(face)) return fail(res, 400, 'Pick one of the listed gift card values.');

  const recipient = normEmail(req.body.recipient);
  if (!validEmail(recipient)) return fail(res, 400, 'Enter the receiver\u2019s email address.');

  const faceP = paise(face);
  const priceP = Math.round(faceP * (1 - GIFT_DISCOUNT));
  const message = String(req.body.message || '').slice(0, 140);

  const pinResult = checkPin(req.user, req.body.pin);
  if (!pinResult.ok) return fail(res, 403, pinResult.message);

  const code = 'LSPG-' + crypto.randomBytes(4).toString('hex').toUpperCase().match(/.{4}/g).join('-');

  let out;
  try {
    out = settle(req.user, {
      amountP: priceP,
      kind: 'giftcard',
      title: `${inr(faceP)} gift card`,
      detail: `Sent to ${recipient}`
    });
  } catch (err) {
    if (err.message === 'INSUFFICIENT') return fail(res, 400, 'Not enough balance for this gift card.');
    throw err;
  }

  db.prepare(
    'INSERT INTO gift_cards (code, face_p, paid_p, buyer_id, recipient) VALUES (?, ?, ?, ?, ?)'
  ).run(code, faceP, priceP, req.user.id, recipient);

  const delivery = await mail.sendGiftCard(recipient, {
    code,
    faceLabel: inr(faceP),
    buyer: req.user.handle,
    message
  });

  res.json({
    ok: true,
    code,
    reference: out.reference,
    points: out.points,
    faceLabel: inr(faceP),
    amountLabel: inr(priceP),
    savedLabel: inr(faceP - priceP),
    recipient,
    delivered: delivery.delivered,
    note: delivery.delivered ? null : `Email not sent: ${delivery.reason}. The code above still works.`,
    user: publicUser(findUserById.get(req.user.id))
  });
});

app.post('/api/giftcards/redeem', auth, (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  const card = db.prepare('SELECT * FROM gift_cards WHERE code = ?').get(code);

  if (!card) return fail(res, 404, 'No gift card matches that code.');
  if (card.redeemed_at) return fail(res, 400, 'That gift card was already redeemed.');
  if (card.recipient !== req.user.email)
    return fail(res, 403, 'That card was sent to a different email address.');

  db.transaction(() => {
    db.prepare('UPDATE users SET balance_p = balance_p + ? WHERE id = ?').run(card.face_p, req.user.id);
    db.prepare('UPDATE gift_cards SET redeemed_by = ?, redeemed_at = datetime(\'now\') WHERE id = ?').run(
      req.user.id,
      card.id
    );
    addTx.run({
      user_id: req.user.id,
      kind: 'receive',
      direction: 'credit',
      amount_p: card.face_p,
      points: 0,
      title: 'Gift card redeemed',
      detail: card.code,
      reference: reference()
    });
  })();

  res.json({
    ok: true,
    creditedLabel: inr(card.face_p),
    user: publicUser(findUserById.get(req.user.id))
  });
});

/* --------------------------------------------------- 6. history & points */

app.get('/api/transactions', auth, (req, res) => {
  const rows = db
    .prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 60')
    .all(req.user.id);

  res.json({
    transactions: rows.map((t) => ({
      kind: t.kind,
      direction: t.direction,
      amountLabel: (t.direction === 'debit' ? '-' : '+') + inr(t.amount_p),
      points: t.points,
      title: t.title,
      detail: t.detail,
      reference: t.reference,
      createdAt: t.created_at
    }))
  });
});

/* ------------------------------------------------------------------ misc */

app.get('/api/health', (req, res) => {
  res.json({ ok: true, mail: process.env.RESEND_API_KEY ? 'resend' : 'console', time: new Date().toISOString() });
});

app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: IS_PROD ? '1h' : 0 }));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return fail(res, 404, 'No such endpoint.');
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.use((err, req, res, next) => {
  console.error('[error]', err);
  fail(res, 500, 'Something broke on our side. Try again.');
});

app.listen(PORT, () => {
  console.log(`LSP-Pay listening on http://localhost:${PORT}`);
  if (!process.env.RESEND_API_KEY) console.log('RESEND_API_KEY missing — codes will print here instead.');
  if (!process.env.JWT_SECRET) console.log('JWT_SECRET missing — sessions reset on restart.');
});
